export default () => {
  return Promise.reject(new Error('foo'))
}
